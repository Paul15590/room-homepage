import './App.css';
import Main from './component/Main';
import Footer from './component/Footer';
function App() {
  return (
    
    <>
      <Main/>
      <Footer/>
    </>
  );
}

export default App;
